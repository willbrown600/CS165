/*************************************************************
 * File: velocity.cpp
 * Author: Will Brown
 *
 * Description: Contains the implementations of the
 *  methods for the velocity class.
 *
 *************************************************************/

#include "velocity.h"

#include <iostream>
using namespace std;


Velocity::Velocity(float dx, float dy)
{
	setDx(dx);
	setDy(dy);
}
