/*************************************************************
 * File: ship.cpp
 * Author: Will Brown
 *
 * Description: Contains the implementations of the
 *  methods for the ship class.
 *
 *************************************************************/

#include "ship.h"


#include <cassert>

void Ship::draw() const
{
	//drawShip(Point & point, int rotation, bool thrust);
}

void Ship::moveLeft()
{
	
}


void Ship::moveRight()
{
	
}

void Ship::moveUp()
{

}


void Ship::moveDown()
{

}

void Ship::fire()
{

}



// Put your ship methods here

