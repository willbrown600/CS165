/*************************************************************
 * File: velocity.h
 * Author: Will Brown
 *
 * Description: This class holds the definitions and prototypes
 * of the velocity class.
 *
 *************************************************************/#pragma once

#ifndef VELOCITY_H
#define VELOCITY_H

#include <iostream>
using namespace std;


class Velocity
{
protected:

	float dx;
	float dy;

public:

	Velocity() : dx(0.0), dy(0.0) {};
	Velocity(float dx, float dy);

	float getDx() { return dx; };
	void setDx(float xSpeed) { dx = xSpeed; };

	float getDy() { return dy; };
	void setDy(float ySpeed) { dy = ySpeed; };
};
// Put your velocity class here, or overwrite this file with your own
// velocity class from the previous project
#endif /* velocity_h */
