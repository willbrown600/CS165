/*************************************************************
 * File: rocks.cpp
 * Author: Will Brown
 *
 * Description: Contains the implementations of the
 *  methods for the rocks class.
 *
 *************************************************************/

#include "rocks.h"
/***************************************
 * ROCK CONSTRUCTOR
 * 
 ***************************************/
Rock::Rock()
{
	setPoint(Point(-200, (float)random(-200, 200)));    //set random point anywhere in the top half
														// but against the left hence -200.
	velocity.setDx(velocity.getDx());					//set velocity as previous velocity plus 0.5.

	alive = true;
}

/***************************************
 * DRAW FUNCTION
 *
 ***************************************/
void Rock::draw()
{

}

/***************************************
 * HIT FUNCTION
 *
 ***************************************
int Rock::hit()
{
	return hits++;
}

/***************************************
 * ADVANCE FUNCTION
 *
 ***************************************/
void Rock::advance()
{

}