/*************************************************************
 * File: rocks.h
 * Author: Will Brown
 *
 * Description: This class holds the definitions and methods
 * of the rocks class.
 *
 *************************************************************/#pragma once

#ifndef ROCKS_H
#define ROCKS_H

#include "flyingObject.h"
#include "point.h"
#include "velocity.h"
#include <iostream>

#define BIG_ROCK_SIZE 16
#define MEDIUM_ROCK_SIZE 8
#define SMALL_ROCK_SIZE 4

#define BIG_ROCK_SPIN 2
#define MEDIUM_ROCK_SPIN 5
#define SMALL_ROCK_SPIN 10



// Define the following classes here:
//   Rock
//   BigRock
//   MediumRock
//   SmallRock

class Rock : public FlyingObject
{
	protected:

		int Score;
		int hits;

	public:

		Rock();

		virtual void advance();
		virtual void draw();
		virtual int hit() { return hits++; }


};

class LargeRock : public Rock
{
protected:

	int size;

public:

	LargeRock() { }

	virtual void advance() { }
	virtual void draw() { }
	virtual int hit() { return hits++; }

};
/*
class MediumRock : public FlyingObject
{
protected:

	int size;

public:

	MediumRock() { }

	virtual void advance() { }
	virtual void draw() { }
	virtual int hit() { }

};

class SmallRock : public FlyingObject
{
protected:

	int size;

public:

	SmallRock() { }

	virtual void draw() { }
	virtual void advance() { }
	virtual void hit() { }

};*/


/*class Bird : public flyingObjects
{
protected:
	int Score = 0;		//declare and initialize Score
	int hits = 0;

public:
	Bird();

	void advance() { flyingObjects::advance(); }	//call flying objects advance function

	virtual void draw()				//virtual draw function due to flying objects  
	{								//and other bird classes with the same function.
		drawCircle(point, 15);
	}
	virtual int hit()
	{
		kill();
		Score++;
		return Score;
	}

};

class standardBird : public Bird
{

protected:

public:

	standardBird()
	{
		//setPoint(Point(-200, (float)random(-200, 200)));

		if ((point.getY()) >= 0)
		{
			velocity.setDy(velocity.getDy() + random(-4, 1));
			velocity.setDx(velocity.getDx() + random(3, 6));
		}
		else
		{
			velocity.setDy(velocity.getDy() + random(1, 4));
			velocity.setDx(velocity.getDx() + random(3, 6));
		}
		//set random point anywhere in the top half
		// but against the left hence -200.
//velocity.setDx(2.0);
//velocity.setDy(1.0);									//set velocity as previous velocity plus 0.5.

		alive = true;
		advance();

	}
	virtual void draw()
	{
		drawCircle(point, 15);				//uses draw bird function to drawbird.
	}
	virtual int hit()
	{
		kill();
		Score++;
		return Score;
	}
};

class ToughBird : public Bird
{
protected:

	int hits = Score;

public:
	ToughBird()
	{

		if ((point.getY()) >= 0)
		{
			velocity.setDy(velocity.getDy() + random(-3, 2));
			velocity.setDx(velocity.getDx() + random(2, 4));
		}
		else
		{
			velocity.setDy(velocity.getDy() + random(1, 3));
			velocity.setDx(velocity.getDx() + random(2, 4));
		}

		/*setPoint(Point(-200.00, (float) random(-200, 200)));   //set random point anywhere in the top half
																// but against the left hence -200.
		velocity.setDx(2.0);
		velocity.setDy(1.0);				//set velocity as previous velocity plus 0.5.8*/

		/*alive = true;
		advance();
		//hits;

	}*/

	/*virtual void draw()
	{
		drawToughBird(point, 12, 3);
	}
	virtual int hit()
	{
		int sumOfhits = 0;
		sumOfhits = hits++;

		if (sumOfhits == 3)
		{
			kill();
			return Score = 5;
		}
		else
		{
			return Score;
		}

	}
};*/

/*class SacredBird : public Bird
{
protected:

public:
	SacredBird()
	{
		if ((point.getY()) >= 0)
		{
			velocity.setDy(velocity.getDy() + random(-1, 3));
			velocity.setDx(velocity.getDx() + random(1, 3));
		}
		else
		{
			velocity.setDy(velocity.getDy() + random(1, 4));
			velocity.setDx(velocity.getDx() + random(1, 3));
		}

		/*setPoint(Point(-200, (float) random(-200, 200)));   //set random point anywhere in the top half
											// but against the left hence -200.
		velocity.setDx(1.0);
		velocity.setDy(1.0);				//set velocity as previous velocity plus 0.5.8*/

		/*alive = true;
		advance();

	}
	virtual void draw()
	{
		drawSacredBird(point, 20);
	}
	virtual int hit()
	{

		kill();
		return Score = -10;

	}
};

class MetalBird : public Bird
{
protected:

public:

	MetalBird()
	{
		if ((point.getY()) >= 0)
		{
			velocity.setDy(velocity.getDy() + 0);
			velocity.setDx(velocity.getDx() + random(1, 7));
		}
		else
		{
			velocity.setDy(velocity.getDy() + 0);
			velocity.setDx(velocity.getDx() + random(1, 7));
		}
		alive = true;
		advance();
	}

	virtual void draw()
	{
		drawLander(point);
		drawLanderFlames(point, 0, left, 0);
	}
	virtual int hit()
	{
		int sumOfhits = 0;
		sumOfhits = hits++;

		if (sumOfhits == 4)
		{
			kill();
			return Score = 8;
		}
		else
		{
			return Score;
		}


	}

};*/

/*class SpaceBird : public Bird
{
protected:

	int hits = Score;

public:
	SpaceBird()
	{

		if ((point.getY()) >= 0)
		{
			velocity.setDy(velocity.getDy() + random(-2, -1));
			velocity.setDx(velocity.getDx() + random(1, 2));
		}
		else
		{
			velocity.setDy(velocity.getDy() + random(1, 2));
			velocity.setDx(velocity.getDx() + random(1, 2));
		}

		/*setPoint(Point(-200.00, (float) random(-200, 200)));   //set random point anywhere in the top half
																// but against the left hence -200.
		velocity.setDx(2.0);
		velocity.setDy(1.0);				//set velocity as previous velocity plus 0.5.8*/

		/*alive = true;
		advance();
		//hits;

	}*/

	/*virtual void draw()
	{
		drawLargeAsteroid(point, 5);
	}
	virtual int hit()
	{
		int sumOfhits = 0;
		sumOfhits = hits++;

		if (sumOfhits == 2)
		{
			kill();
			return Score = 3;
		}
		else
		{
			return Score;
		}

	}
};

class BigBird : public Bird
{
protected:

	int hits = Score;

public:
	BigBird()
	{

		if ((point.getY()) >= 0)
		{
			velocity.setDy(velocity.getDy() + random(-2, -1));
			velocity.setDx(velocity.getDx() + random(1, 3));
		}
		else
		{
			velocity.setDy(velocity.getDy() + random(1, 2));
			velocity.setDx(velocity.getDx() + random(1, 4));
		}

		/*setPoint(Point(-200.00, (float) random(-200, 200)));   //set random point anywhere in the top half
																// but against the left hence -200.
		velocity.setDx(2.0);
		velocity.setDy(1.0);				//set velocity as previous velocity plus 0.5.8*/

		/*alive = true;
		advance();
		//hits;

	}

	virtual void draw()
	{
		drawPolygon(point, 20, 5, 5);

	}
	virtual int hit()
	{
		int sumOfhits = 0;
		sumOfhits = hits++;

		if (sumOfhits == 5)
		{
			kill();
			return Score = 10;
		}
		else
		{
			return Score;
		}

	}
};*/
#endif /* rocks_h */
