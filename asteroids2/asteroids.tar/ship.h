/*************************************************************
 * File: ship.h
 * Author: Will Brown
 *
 * Description: This class holds the definitions and methods
 * of the ship class.
 *
 *************************************************************/#pragma once

#ifndef ship_h
#define ship_h

#include "flyingObject.h"
#include <iostream>

#define SHIP_SIZE 10

#define ROTATE_AMOUNT 6
#define THRUST_AMOUNT 0.5

class Ship : public FlyingObject
{
private:
	Point point;

	
	float angle;
	float endpoint;


public:
	
	Ship(const Point & point) : point(point) { }

	/****************
	 * Basic Getters
	 ****************/
	float getAngle() const { return angle; }
	Point getPoint() const { return point; }
	//Point getEndPoint() const { return point * angle; }
	/*****************
	 * Drawing
	 *****************/
	void draw() const;
	//void drawLine(point,

	/*****************
	 * Movement
	 *****************/
	void moveLeft();
	void moveRight();
	void moveUp();
	void moveDown();
	void fire();

};

#endif